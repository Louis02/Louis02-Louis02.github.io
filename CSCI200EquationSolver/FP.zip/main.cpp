#include "Operation.h"
#include "EventHandler.h"

#include <iostream>
#include <string>

int main(){
    EventHandler eh;

    return 0;
}